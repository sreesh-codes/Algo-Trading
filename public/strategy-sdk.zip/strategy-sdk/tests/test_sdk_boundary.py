"""Boundary tests for the participant SDK.

These exercise the safety-critical surface: validation, read-only views, controlled actions,
and the absence of any engine/OS capability. They use an in-memory RecordingBroker and have
NO dependency on the market engine, so they run under a bare interpreter:

    PYTHONPATH=src python3 tests/test_sdk_boundary.py     # standalone
    pytest                                                # or via pytest

Every function named ``test_*`` is a check; the ``__main__`` block runs them all.
"""
from __future__ import annotations

import os
import sys
from decimal import Decimal

# Allow standalone execution (python3 tests/test_sdk_boundary.py) without install.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from mercantile_sdk import (  # noqa: E402
    AccountState,
    AssetSpec,
    Level,
    MarketSnapshot,
    MarketView,
    OrderBookView,
    Position,
    RecordingBroker,
    Side,
    Strategy,
    TradingContext,
    coerce_decimal,
)
from mercantile_sdk.errors import (  # noqa: E402
    InsufficientCash,
    InvalidPrice,
    InvalidQuantity,
    NotConnected,
    PositionLimitExceeded,
    UnknownOrder,
    UnknownSymbol,
)


def D(x):
    return Decimal(str(x))


def make_ctx(cash="100000", position_qty="0", best_bid="99.75", best_ask="100.25", limit="100"):
    spec = AssetSpec("AURUM", D("0.25"), D("1"), 2, D(limit))
    registry = {"AURUM": spec}
    acct = AccountState(initial_cash=D(cash), cash=D(cash))
    if D(position_qty) != 0:
        acct.positions["AURUM"] = Position("AURUM", D(position_qty), D("100"), D(0), D(0))
    snap = MarketSnapshot(step=0, timestamp=0)
    snap.books["AURUM"] = OrderBookView(
        "AURUM", bids=(Level(D(best_bid), D("50")),), asks=(Level(D(best_ask), D("50")),)
    )
    snap.last_price["AURUM"] = D("100.00")
    snap.volume["AURUM"] = D("1234")
    broker = RecordingBroker()
    ctx = TradingContext(broker, registry, acct, snap, "AURUM")
    return ctx, broker, acct, snap, spec


def expect_raises(exc, fn, *a, **k):
    try:
        fn(*a, **k)
    except exc:
        return
    raise AssertionError(f"expected {exc.__name__} but no error was raised")


# --- coercion --------------------------------------------------------------------------

def test_coerce_decimal_accepts_numbers_including_float():
    assert coerce_decimal(5) == D(5)
    assert coerce_decimal(100.5) == D("100.5")  # float allowed for students
    assert coerce_decimal("3.25") == D("3.25")


def test_coerce_decimal_rejects_bool_and_garbage():
    expect_raises(TypeError, coerce_decimal, True)
    expect_raises(ValueError, coerce_decimal, "abc")


# --- validation ------------------------------------------------------------------------

def test_market_buy_records_order():
    ctx, broker, *_ = make_ctx()
    r = ctx.buy(quantity=3)
    assert r.side is Side.BUY and r.order_type.value == "MARKET" and r.quantity == D(3)
    assert len(broker.submitted) == 1 and broker.submitted[0][0] == r.order_id


def test_zero_and_negative_quantity_rejected():
    ctx, *_ = make_ctx()
    expect_raises(InvalidQuantity, ctx.buy, "AURUM", 0)
    expect_raises(InvalidQuantity, ctx.buy, "AURUM", -5)


def test_non_lot_quantity_rejected():
    ctx, *_ = make_ctx()
    expect_raises(InvalidQuantity, ctx.buy, "AURUM", 1.5)


def test_unknown_symbol_rejected():
    ctx, *_ = make_ctx()
    expect_raises(UnknownSymbol, ctx.buy, "GOLD", 1)


def test_limit_price_validation():
    ctx, *_ = make_ctx()
    expect_raises(InvalidPrice, ctx.place_limit_order, "AURUM", Side.BUY, 1, 0)
    expect_raises(InvalidPrice, ctx.place_limit_order, "AURUM", Side.BUY, 1, -10)
    expect_raises(InvalidPrice, ctx.place_limit_order, "AURUM", Side.BUY, 1, "100.10")  # off tick


def test_valid_limit_order_is_tracked_and_cancellable():
    ctx, broker, *_ = make_ctx()
    r = ctx.place_limit_order("AURUM", Side.BUY, 5, "99.50")
    assert r.status == "OPEN" and r.order_id in ctx.open_order_ids
    ctx.cancel_order(r.order_id)
    assert r.order_id not in ctx.open_order_ids
    assert broker.cancelled == [r.order_id]


def test_cancel_unknown_order_rejected():
    ctx, *_ = make_ctx()
    expect_raises(UnknownOrder, ctx.cancel_order, "NOPE-1")


def test_position_limit_single_order():
    ctx, *_ = make_ctx(limit="100")
    expect_raises(PositionLimitExceeded, ctx.buy, "AURUM", 101)


def test_position_limit_stacked_open_orders():
    ctx, *_ = make_ctx(limit="100")
    ctx.place_limit_order("AURUM", Side.BUY, 60, "99.50")  # ok (pending 60)
    expect_raises(PositionLimitExceeded, ctx.place_limit_order, "AURUM", Side.BUY, 60, "99.25")


def test_position_limit_short_side():
    ctx, *_ = make_ctx(limit="100")
    expect_raises(PositionLimitExceeded, ctx.sell, "AURUM", 101)


def test_insufficient_cash_on_market_buy():
    ctx, *_ = make_ctx(cash="1000")  # best ask 100.25, buy 20 -> ~2005 > 1000
    expect_raises(InsufficientCash, ctx.buy, "AURUM", 20)


# --- read-only market view -------------------------------------------------------------

def test_market_view_public_and_account_reads():
    _, _, acct, snap, _ = make_ctx(position_qty="7")
    mv = MarketView(snap, acct, ["AURUM"], "AURUM")
    assert mv.bid() == D("99.75")
    assert mv.ask() == D("100.25")
    assert mv.mid() == D("100.00")
    assert mv.spread() == D("0.50")
    assert mv.price() == D("100.00")
    assert mv.volume() == D("1234")
    assert mv.position().quantity == D("7")
    assert mv.cash == D("100000")


def test_market_view_default_symbol_and_unknown():
    _, _, acct, snap, _ = make_ctx()
    mv = MarketView(snap, acct, ["AURUM"], "AURUM")
    assert mv.price() == mv.price("AURUM")  # default symbol
    expect_raises(UnknownSymbol, mv.price, "ZZZ")


def test_order_book_view_is_immutable():
    book = OrderBookView("AURUM", bids=(Level(D("99.75"), D("10")),), asks=())
    try:
        book.bids = ()  # frozen dataclass
    except Exception:
        return
    raise AssertionError("OrderBookView should be immutable")


# --- strategy binding & capability boundary --------------------------------------------

def test_actions_require_running_context():
    class S(Strategy):
        pass

    s = S()
    expect_raises(NotConnected, s.buy)
    expect_raises(NotConnected, lambda: s.cash)


def test_bound_strategy_can_trade_and_read():
    ctx, broker, acct, snap, _ = make_ctx()
    mv = MarketView(snap, acct, ["AURUM"], "AURUM")

    class S(Strategy):
        def on_tick(self, market):
            if market.position().quantity == 0:
                self.buy(quantity=2)

    s = S()
    s._bind(ctx, mv)
    s.on_tick(s.market)
    assert len(broker.submitted) == 1
    assert s.cash == D("100000")


def test_sdk_core_has_no_engine_dependency():
    # Importing the SDK core must NOT pull in the market engine (the boundary): the engine
    # is loaded lazily only by the local simulator.
    assert "mercantile_sim" not in sys.modules, "SDK core must not import the engine"
    # And a strategy exposes no filesystem/network/db handles.
    s = Strategy()
    for forbidden in ("open", "os", "socket", "connect", "db", "database", "broker"):
        assert not hasattr(s, forbidden), f"Strategy must not expose {forbidden!r}"


# --- standalone runner (works without pytest) ------------------------------------------

if __name__ == "__main__":
    tests = sorted(k for k, v in list(globals().items()) if k.startswith("test_") and callable(v))
    failed = 0
    for name in tests:
        try:
            globals()[name]()
            print(f"PASS {name}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            print(f"FAIL {name}: {type(exc).__name__}: {exc}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
