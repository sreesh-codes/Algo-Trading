# packages/strategy-sdk — The student-facing strategy API

**Status: not yet implemented (Phase 4).**

## Purpose
The narrow, documented Python API that students import to write strategies. Exposes market
data access, order primitives, and portfolio/position state — and deliberately nothing else.

## Why it exists
It is the boundary that keeps untrusted student code away from infrastructure. Students
program against this SDK; they never see the database, the network, or hidden competition
parameters. Combined with the sandbox ([ADR-0006](../../docs/adr/0006-sandbox-isolation.md)),
this enforces "student code never touches the backend DB."

## Design intent
- Stable, minimal, well-documented surface (students depend on it directly).
- Same interface for local backtests and competition submission, so a strategy that runs
  locally runs identically when submitted (subject to hidden data).
