"""Local simulator so students can run ``python strategy.py`` and test offline.

This is the ONLY part of the SDK that imports the market engine (``mercantile_sim``); it is
loaded lazily (see ``__init__``). It wires a student :class:`Strategy` into the deterministic
Phase 2 exchange: a market maker provides liquidity, noise flow creates volume, and the
student trades against the public feed. Determinism comes from a single seed.

Usage::

    from mercantile_sdk import Strategy, run_local
    class MyStrategy(Strategy):
        def on_tick(self, market): ...
    if __name__ == "__main__":
        run_local(MyStrategy)

The competition server will provide a different backend behind the same SDK — students'
strategy code does not change.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, List, Optional, Union

from mercantile_sim import Asset, AssetType, FeeSchedule, Portfolio
from mercantile_sim.enums import Liquidity as ELiquidity
from mercantile_sim.enums import OrderType as EOrderType
from mercantile_sim.enums import Side as ESide
from mercantile_sim.exchange import MarketClock, MatchingEngine
from mercantile_sim.market import MODEL_REGISTRY, EventScheduler, MarketMaker, NoiseFlow, Rng
from mercantile_sim.market.accounting import apply_fill_to_portfolio
from mercantile_sim.market.conditions import MarketConditions

from .broker import Broker
from .context import TradingContext
from .market import MarketView
from .state import AccountState, MarketSnapshot
from .strategy import Strategy
from .types import (
    AssetSpec,
    Fill,
    Level,
    Liquidity,
    OrderBookView,
    OrderType,
    Position,
    Side,
    TradeView,
)

__all__ = ["SimConfig", "AssetConfig", "LocalSimulator", "SimResult", "run_local"]

_ZERO = Decimal(0)
_STUDENT = "you"
_DEPTH_LEVELS = 5


def _d(x) -> Decimal:
    return x if isinstance(x, Decimal) else Decimal(str(x))


@dataclass
class AssetConfig:
    symbol: str = "AURUM"
    tick_size: str = "0.25"
    lot_size: str = "1"
    price_precision: int = 2
    position_limit: str = "1000"
    initial_price: float = 100.0


@dataclass
class SimConfig:
    assets: List[AssetConfig] = field(default_factory=lambda: [AssetConfig()])
    model: str = "random_walk"
    model_params: Dict[str, object] = field(default_factory=dict)
    steps: int = 500
    seed: int = 42
    starting_cash: str = "100000"
    taker_fee_bps: float = 0.0
    maker_fee_bps: float = 0.0
    mm_levels: int = 5
    mm_spread_bps: float = 10.0
    mm_base_size: str = "50"
    noise_max_orders: int = 3
    noise_order_prob: float = 0.6
    events: list = field(default_factory=list)
    verbose: bool = True

    @property
    def primary_symbol(self) -> str:
        return self.assets[0].symbol


@dataclass
class SimResult:
    steps: int
    start_prices: Dict[str, Optional[Decimal]]
    final_prices: Dict[str, Optional[Decimal]]
    student_cash: Decimal
    student_positions: Dict[str, Decimal]
    student_pnl: Decimal
    own_fills: int
    market_trades: int
    market_volume: Dict[str, Decimal]


class _EngineBroker(Broker):
    """Broker implementation that routes student orders into the matching engine."""

    def __init__(self, engine: MatchingEngine) -> None:
        self._engine = engine

    def submit(self, symbol, side, order_type, quantity, price) -> str:
        eside = ESide(side.value)
        eot = EOrderType(order_type.value)
        order, _trades = self._engine.submit(symbol, _STUDENT, eside, eot, quantity, price)
        return order.order_id

    def cancel(self, order_id: str) -> None:
        self._engine.cancel(order_id)


class LocalSimulator:
    def __init__(self, strategy: Strategy, config: SimConfig) -> None:
        self.config = config
        self.strategy = strategy

        # --- build assets + engine ---
        self.assets = [
            Asset(
                asset_id=a.symbol, symbol=a.symbol, name=a.symbol,
                asset_type=AssetType.COMMODITY,
                tick_size=_d(a.tick_size), lot_size=_d(a.lot_size),
                price_precision=a.price_precision, position_limit=_d(a.position_limit),
            )
            for a in config.assets
        ]
        self.asset_ids = [a.asset_id for a in self.assets]
        self.primary = config.primary_symbol
        self.clock = MarketClock()
        self.engine = MatchingEngine({a.asset_id: a for a in self.assets}, clock=self.clock)

        # --- market model ---
        if config.model not in MODEL_REGISTRY:
            raise KeyError(f"unknown model {config.model!r}; choose one of "
                           f"{sorted(MODEL_REGISTRY)}")
        params = dict(config.model_params)
        params.setdefault(
            "initial_prices", {a.symbol: a.initial_price for a in config.assets}
        )
        self.model = MODEL_REGISTRY[config.model](
            seed=config.seed, parameters=params, assets=self.assets
        )
        self.model.reset()

        # --- microstructure ---
        self.conditions = MarketConditions()
        self.events = EventScheduler(list(config.events))
        self.rng = Rng(config.seed, "localsim")
        self.mm = MarketMaker(
            self.engine, levels=config.mm_levels, base_spread_bps=config.mm_spread_bps,
            base_size=_d(config.mm_base_size),
        )
        self.noise = NoiseFlow(
            self.engine, rng=self.rng.spawn("noise"),
            max_orders_per_step=config.noise_max_orders, order_prob=config.noise_order_prob,
        )
        self.fees = FeeSchedule(
            maker_rate=_d(config.maker_fee_bps) / _d(10000),
            taker_rate=_d(config.taker_fee_bps) / _d(10000),
        )

        # --- accounts ---
        big = Decimal("1000000000000")
        self.portfolios: Dict[str, Portfolio] = {
            "MM": Portfolio(initial_cash=big),
            "NOISE": Portfolio(initial_cash=big),
            _STUDENT: Portfolio(initial_cash=_d(config.starting_cash)),
        }

        # --- SDK-facing state, bound once (mutated in place each step) ---
        self.registry: Dict[str, AssetSpec] = {
            a.asset_id: AssetSpec(a.asset_id, a.tick_size, a.lot_size,
                                  a.price_precision, a.position_limit)
            for a in self.assets
        }
        self.account = AccountState(
            initial_cash=_d(config.starting_cash), cash=_d(config.starting_cash)
        )
        self.snapshot = MarketSnapshot()
        self.broker = _EngineBroker(self.engine)
        self.context = TradingContext(
            self.broker, self.registry, self.account, self.snapshot, self.primary
        )
        self.view = MarketView(self.snapshot, self.account, self.asset_ids, self.primary)
        self.strategy._bind(self.context, self.view)
        self._own_fills = 0

    # --- snapshot / account refresh (mutate in place so bound refs see updates) --------

    def _refresh_snapshot(self) -> None:
        self.snapshot.step = self.clock.step
        self.snapshot.timestamp = self.clock.timestamp
        for aid in self.asset_ids:
            book = self.engine.books[aid]
            bids = tuple(Level(p, q) for p, q in book.depth(ESide.BUY, _DEPTH_LEVELS))
            asks = tuple(Level(p, q) for p, q in book.depth(ESide.SELL, _DEPTH_LEVELS))
            self.snapshot.books[aid] = OrderBookView(aid, bids=bids, asks=asks)
            last = self.engine.tape.last_price(aid)
            if last is not None:
                self.snapshot.last_price[aid] = last
            self.snapshot.volume[aid] = self.engine.tape.volume(aid)
            self.snapshot.recent_trades[aid] = tuple(
                TradeView(t.asset_id, t.price, t.quantity, Side(t.taker_side.value),
                          t.timestamp)
                for t in self.engine.tape.recent(20, asset_id=aid)
            )

    def _mark_and_refresh_account(self) -> None:
        port = self.portfolios[_STUDENT]
        for aid in self.asset_ids:
            mid = self.engine.books[aid].mid_price()
            price = mid if mid is not None else self.engine.tape.last_price(aid)
            if price is not None:
                port.set_mark(aid, price)
        self.account.cash = port.cash
        self.account.equity = port.equity
        self.account.realized_pnl = port.realized_pnl
        self.account.unrealized_pnl = port.unrealized_pnl
        self.account.positions = {
            aid: Position(aid, p.quantity, p.average_entry_price, p.realized_pnl,
                          p.unrealized_pnl)
            for aid, p in port.positions.items()
        }

    # --- per-step trade processing -----------------------------------------------------

    def _process_trades(self, tape_start: int) -> Dict[str, float]:
        signed: Dict[str, float] = {aid: 0.0 for aid in self.asset_ids}
        for tr in self.engine.tape.all[tape_start:]:
            notional = tr.price * tr.quantity
            taker_fee = self.fees.compute_fee(notional, ELiquidity.TAKER)
            maker_fee = self.fees.compute_fee(notional, ELiquidity.MAKER)
            apply_fill_to_portfolio(self._port(tr.taker_trader), tr.asset_id,
                                    tr.taker_side, tr.quantity, tr.price, taker_fee)
            apply_fill_to_portfolio(self._port(tr.maker_trader), tr.asset_id,
                                    tr.taker_side.opposite(), tr.quantity, tr.price, maker_fee)
            # public print
            self._safe(self.strategy.on_trade, TradeView(
                tr.asset_id, tr.price, tr.quantity, Side(tr.taker_side.value), tr.timestamp))
            # own fills
            if tr.taker_trader == _STUDENT:
                self._deliver_fill(tr, side=tr.taker_side, liq=Liquidity.TAKER,
                                   fee=taker_fee, order_id=tr.taker_order_id)
            if tr.maker_trader == _STUDENT:
                self.context._notify_fill(tr.maker_order_id, tr.quantity)
                self._deliver_fill(tr, side=tr.taker_side.opposite(), liq=Liquidity.MAKER,
                                   fee=maker_fee, order_id=tr.maker_order_id)
            signed[tr.asset_id] += (1.0 if tr.taker_side is ESide.BUY else -1.0) * float(
                tr.quantity)
        return signed

    def _deliver_fill(self, tr, side, liq, fee, order_id) -> None:
        self._own_fills += 1
        self._safe(self.strategy.on_fill, Fill(
            order_id=order_id, symbol=tr.asset_id, side=Side(side.value),
            quantity=tr.quantity, price=tr.price, fee=fee, liquidity=liq,
            timestamp=tr.timestamp))

    def _port(self, trader_id: str) -> Portfolio:
        p = self.portfolios.get(trader_id)
        if p is None:
            p = Portfolio(initial_cash=_ZERO)
            self.portfolios[trader_id] = p
        return p

    @staticmethod
    def _safe(fn, arg) -> None:
        # A crash in a student hook should stop the sim with a clear traceback, not be
        # silently swallowed — so we deliberately do NOT catch here.
        fn(arg)

    # --- run ---------------------------------------------------------------------------

    def run(self) -> SimResult:
        cfg = self.config
        self.strategy.on_start()
        start_prices: Dict[str, Optional[Decimal]] = {}

        for _ in range(cfg.steps):
            t = self.clock.step
            self.events.apply(t, self.conditions)
            tick = self.model.step(t, self.conditions)
            tape_start = len(self.engine.tape)

            for aid in self.asset_ids:
                self.mm.requote(aid, tick.reference_prices[aid], self.conditions)
            for aid in self.asset_ids:
                self.noise.generate(aid, tick.flow_bias.get(aid, 0.0))

            self._refresh_snapshot()
            self._mark_and_refresh_account()
            if not start_prices:
                start_prices = {aid: self.engine.books[aid].mid_price()
                                for aid in self.asset_ids}

            self.strategy.on_orderbook(self.view.order_book(self.primary))
            self.strategy.on_tick(self.view)

            signed = self._process_trades(tape_start)
            self.conditions.last_signed_volume = signed
            self._mark_and_refresh_account()
            self.clock.tick()

        self.strategy.on_end()
        return self._build_result(start_prices)

    def _build_result(self, start_prices) -> SimResult:
        port = self.portfolios[_STUDENT]
        final_prices = {aid: self.engine.books[aid].mid_price() for aid in self.asset_ids}
        result = SimResult(
            steps=self.config.steps,
            start_prices=start_prices,
            final_prices=final_prices,
            student_cash=port.cash,
            student_positions={aid: p.quantity for aid, p in port.positions.items()},
            student_pnl=port.equity - port.initial_cash,
            own_fills=self._own_fills,
            market_trades=len(self.engine.tape),
            market_volume={aid: self.engine.tape.volume(aid) for aid in self.asset_ids},
        )
        if self.config.verbose:
            self._print_summary(result)
        return result

    def _print_summary(self, r: SimResult) -> None:
        q = lambda d: (d.quantize(Decimal("0.01")) if d is not None else None)
        print("\n" + "=" * 56)
        print(f" LOCAL SIMULATION — {getattr(self.strategy, 'name', 'Strategy')} "
              f"v{getattr(self.strategy, 'version', '?')}")
        print("=" * 56)
        print(f" model={self.config.model}  steps={r.steps}  seed={self.config.seed}")
        for aid in self.asset_ids:
            print(f"  {aid}: price {q(r.start_prices.get(aid))} -> {q(r.final_prices.get(aid))}"
                  f"   volume {r.market_volume.get(aid)}")
        print(f" your fills:      {r.own_fills}")
        print(f" your positions:  {r.student_positions}")
        print(f" your cash:       {q(r.student_cash)}")
        print(f" your PnL:        {q(r.student_pnl)}")
        print("=" * 56 + "\n")


def run_local(
    strategy: Union[Strategy, type], config: Optional[SimConfig] = None, **overrides
) -> SimResult:
    """Build a strategy (from a class or instance) and run it against the local simulator.

    Extra keyword args override :class:`SimConfig` fields, e.g.
    ``run_local(MyStrategy, steps=1000, seed=7, model="mean_reverting")``.
    """
    if isinstance(strategy, type):
        strategy = strategy()
    cfg = config or SimConfig()
    for key, value in overrides.items():
        if not hasattr(cfg, key):
            raise TypeError(f"unknown SimConfig option {key!r}")
        setattr(cfg, key, value)
    return LocalSimulator(strategy, cfg).run()
