"""SDK error hierarchy.

All raised to the student's code with clear, actionable messages. ``OrderRejected`` and its
subclasses mean "your order was not accepted" — the engine state is unchanged.
"""
from __future__ import annotations

__all__ = [
    "SDKError",
    "OrderRejected",
    "UnknownSymbol",
    "InvalidQuantity",
    "InvalidPrice",
    "PositionLimitExceeded",
    "InsufficientCash",
    "UnknownOrder",
    "NotConnected",
]


class SDKError(Exception):
    """Base class for all SDK errors."""


class OrderRejected(SDKError):
    """An order failed validation and was not submitted."""


class UnknownSymbol(OrderRejected):
    pass


class InvalidQuantity(OrderRejected):
    pass


class InvalidPrice(OrderRejected):
    pass


class PositionLimitExceeded(OrderRejected):
    pass


class InsufficientCash(OrderRejected):
    pass


class UnknownOrder(SDKError):
    """Referenced an order id the SDK does not know about."""


class NotConnected(SDKError):
    """A trading action was called outside a running simulation/competition."""
