"""Mutable state the runner updates each step and the SDK exposes read-only.

Strategies never touch these directly; they read through :class:`MarketView` and act through
:class:`TradingContext`. The runner (local simulator or competition server) owns and updates
them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Tuple

from .types import OrderBookView, Position, TradeView

__all__ = ["AccountState", "MarketSnapshot"]

_ZERO = Decimal(0)


@dataclass
class AccountState:
    """Your cash, positions and PnL at the current step."""

    initial_cash: Decimal
    cash: Decimal
    equity: Decimal = _ZERO
    realized_pnl: Decimal = _ZERO
    unrealized_pnl: Decimal = _ZERO
    positions: Dict[str, Position] = field(default_factory=dict)

    @property
    def total_pnl(self) -> Decimal:
        return self.equity - self.initial_cash

    def position(self, symbol: str) -> Position:
        return self.positions.get(
            symbol, Position(symbol, _ZERO, _ZERO, _ZERO, _ZERO)
        )


@dataclass
class MarketSnapshot:
    """Public market data for the current step (one entry per symbol)."""

    step: int = 0
    timestamp: int = 0
    books: Dict[str, OrderBookView] = field(default_factory=dict)
    last_price: Dict[str, Decimal] = field(default_factory=dict)
    volume: Dict[str, Decimal] = field(default_factory=dict)
    recent_trades: Dict[str, Tuple[TradeView, ...]] = field(default_factory=dict)
