"""mercantile_sdk — the participant trading SDK for DUBAI 2035: THE MERCANTILE.

The one interface students need to write strategies. Subclass :class:`Strategy`, override
the hooks, and run it locally::

    from mercantile_sdk import Strategy, Side, run_local

    class MyStrategy(Strategy):
        def on_tick(self, market):
            if market.position().quantity == 0:
                self.buy(quantity=1)

    if __name__ == "__main__":
        run_local(MyStrategy)

The SDK core (types, validation, Strategy, MarketView, TradingContext) has **no** dependency
on the market engine, database, filesystem, or network — that is the safety boundary. Only
the local simulator (:func:`run_local`) imports the engine, and it is loaded lazily so the
core stays importable on its own.
"""
from __future__ import annotations

from .broker import Broker, RecordingBroker
from .context import TradingContext
from .errors import (
    InsufficientCash,
    InvalidPrice,
    InvalidQuantity,
    NotConnected,
    OrderRejected,
    PositionLimitExceeded,
    SDKError,
    UnknownOrder,
    UnknownSymbol,
)
from .market import MarketView
from .state import AccountState, MarketSnapshot
from .strategy import Strategy
from .types import (
    AssetSpec,
    Fill,
    Level,
    Liquidity,
    OrderBookView,
    OrderReceipt,
    OrderType,
    Position,
    Side,
    TradeView,
    coerce_decimal,
)

__version__ = "0.1.0"

__all__ = [
    "__version__",
    # strategy + views
    "Strategy",
    "MarketView",
    "TradingContext",
    # types
    "Side",
    "OrderType",
    "Liquidity",
    "AssetSpec",
    "Level",
    "OrderBookView",
    "TradeView",
    "Fill",
    "Position",
    "OrderReceipt",
    "coerce_decimal",
    # state
    "AccountState",
    "MarketSnapshot",
    # broker
    "Broker",
    "RecordingBroker",
    # errors
    "SDKError",
    "OrderRejected",
    "UnknownSymbol",
    "InvalidQuantity",
    "InvalidPrice",
    "PositionLimitExceeded",
    "InsufficientCash",
    "UnknownOrder",
    "NotConnected",
    # local simulator (lazy)
    "run_local",
    "LocalSimulator",
    "SimConfig",
]


def run_local(*args, **kwargs):
    """Run a strategy against the built-in local simulator (imports the engine lazily)."""
    from .localsim import run_local as _run_local

    return _run_local(*args, **kwargs)


def __getattr__(name: str):
    # PEP 562 lazy access so `from mercantile_sdk import LocalSimulator` works without
    # importing the engine until it is actually needed.
    if name in {"LocalSimulator", "SimConfig"}:
        from . import localsim

        return getattr(localsim, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
