"""The execution backend abstraction.

The SDK talks to the market only through this narrow :class:`Broker` interface. The local
simulator provides one implementation (backed by ``mercantile_sim``); the real competition
server will provide another. Because the SDK core depends only on this protocol — never on
the engine, a database, the filesystem, or the network — the participant boundary is small,
explicit, and testable.

:class:`RecordingBroker` is an in-memory fake used by the boundary tests and for offline
experimentation: it records submissions and can be driven to emit fills.
"""
from __future__ import annotations

from decimal import Decimal
from typing import List, Optional, Protocol, Tuple, runtime_checkable

from .types import OrderType, Side

__all__ = ["Broker", "RecordingBroker"]


@runtime_checkable
class Broker(Protocol):
    def submit(
        self,
        symbol: str,
        side: Side,
        order_type: OrderType,
        quantity: Decimal,
        price: Optional[Decimal],
    ) -> str:
        """Submit a validated order. Returns the broker-assigned order id."""
        ...

    def cancel(self, order_id: str) -> None:
        """Cancel a resting order by id."""
        ...


class RecordingBroker:
    """An in-memory Broker that records orders and cancels. No matching/fills of its own."""

    def __init__(self) -> None:
        self.submitted: List[Tuple[str, str, Side, OrderType, Decimal, Optional[Decimal]]] = []
        self.cancelled: List[str] = []
        self._seq = 0

    def submit(self, symbol, side, order_type, quantity, price) -> str:
        self._seq += 1
        oid = f"REC-{self._seq:06d}"
        self.submitted.append((oid, symbol, side, order_type, quantity, price))
        return oid

    def cancel(self, order_id: str) -> None:
        self.cancelled.append(order_id)
