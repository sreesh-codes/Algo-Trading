"""Pure pre-trade validation used by :class:`TradingContext`.

Kept dependency-free (no ``mercantile_sim``) so the safety boundary can be tested in
isolation. Each function returns the normalised Decimal or raises a specific
:class:`OrderRejected` subclass with a student-friendly message.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Dict, Optional

from .errors import (
    InsufficientCash,
    InvalidPrice,
    InvalidQuantity,
    PositionLimitExceeded,
    UnknownSymbol,
)
from .types import AssetSpec, Side, coerce_decimal

__all__ = [
    "require_symbol",
    "validate_quantity",
    "validate_price",
    "check_position_limit",
    "check_cash",
]

_ZERO = Decimal(0)


def _is_multiple_of(value: Decimal, step: Decimal) -> bool:
    if step <= 0:
        return True
    return (value % step) == _ZERO


def _decimal_places(value: Decimal) -> int:
    exp = value.normalize().as_tuple().exponent
    return -exp if isinstance(exp, int) and exp < 0 else 0


def require_symbol(registry: Dict[str, AssetSpec], symbol: str) -> AssetSpec:
    spec = registry.get(symbol)
    if spec is None:
        known = ", ".join(sorted(registry)) or "(none)"
        raise UnknownSymbol(f"unknown symbol {symbol!r}; tradable symbols: {known}")
    return spec


def validate_quantity(spec: AssetSpec, quantity) -> Decimal:
    q = coerce_decimal(quantity, field_name="quantity")
    if q <= _ZERO:
        raise InvalidQuantity(f"quantity must be positive, got {q}")
    if not _is_multiple_of(q, spec.lot_size):
        raise InvalidQuantity(
            f"quantity {q} must be a multiple of the lot size {spec.lot_size} for "
            f"{spec.symbol}"
        )
    return q


def validate_price(spec: AssetSpec, price) -> Decimal:
    p = coerce_decimal(price, field_name="price")
    if p <= _ZERO:
        raise InvalidPrice(f"price must be positive, got {p}")
    if _decimal_places(p) > spec.price_precision:
        raise InvalidPrice(
            f"price {p} has too many decimal places (max {spec.price_precision} for "
            f"{spec.symbol})"
        )
    if not _is_multiple_of(p, spec.tick_size):
        raise InvalidPrice(
            f"price {p} must be a multiple of the tick size {spec.tick_size} for "
            f"{spec.symbol}"
        )
    return p


def check_position_limit(
    spec: AssetSpec,
    current_qty: Decimal,
    side: Side,
    quantity: Decimal,
    pending_buy: Decimal = _ZERO,
    pending_sell: Decimal = _ZERO,
) -> None:
    """Reject if the worst-case resulting position would breach +/- position_limit."""
    if side is Side.BUY:
        pending_buy = pending_buy + quantity
    else:
        pending_sell = pending_sell + quantity
    if current_qty + pending_buy > spec.position_limit:
        raise PositionLimitExceeded(
            f"order would allow a long position of "
            f"{current_qty + pending_buy} in {spec.symbol}, above the limit "
            f"{spec.position_limit}"
        )
    if current_qty - pending_sell < -spec.position_limit:
        raise PositionLimitExceeded(
            f"order would allow a short position of "
            f"{current_qty - pending_sell} in {spec.symbol}, below the limit "
            f"-{spec.position_limit}"
        )


def check_cash(available_cash: Decimal, estimated_cost: Optional[Decimal]) -> None:
    if estimated_cost is None:
        return  # no reference price available -> cannot pre-check (e.g. market buy, empty book)
    if estimated_cost > available_cash:
        raise InsufficientCash(
            f"order needs about {estimated_cost} but you only have {available_cash} cash"
        )
