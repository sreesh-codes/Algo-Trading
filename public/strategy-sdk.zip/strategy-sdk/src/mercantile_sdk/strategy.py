"""The ``Strategy`` base class — what students subclass.

Override any of the lifecycle hooks (all optional, default to no-ops):

    on_start()            once, before trading begins
    on_orderbook(book)    each step, with the current order book (read-only)
    on_tick(market)       each step, with the market view (read-only)
    on_trade(trade)       for each public trade printed to the tape
    on_fill(fill)         for each fill of YOUR own orders
    on_end()              once, after trading ends

Take actions with the convenience methods (validated before they reach the market):

    self.buy(symbol=None, quantity=1)
    self.sell(symbol=None, quantity=1)
    self.place_limit_order(symbol, side, quantity, price)
    self.cancel_order(order_id)

Read state via ``self.market`` (a MarketView) or the shortcuts ``self.position()``,
``self.cash``, ``self.pnl``. A strategy has NO other capabilities — no filesystem, no
network, no database, no access to hidden parameters or other teams.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Optional

from .context import TradingContext
from .errors import NotConnected
from .market import MarketView
from .types import Number, OrderBookView, OrderReceipt, Position, Side, TradeView, Fill

__all__ = ["Strategy"]


class Strategy:
    #: Optional human-readable name + version (version is recorded for reproducible replay).
    name: str = "Strategy"
    version: str = "0.1.0"

    # Bound by the runner before on_start(); not set by students.
    _ctx: Optional[TradingContext] = None
    _market: Optional[MarketView] = None

    # --- lifecycle hooks (override these) ---------------------------------------------

    def on_start(self) -> None:
        pass

    def on_orderbook(self, orderbook: OrderBookView) -> None:
        pass

    def on_tick(self, market: MarketView) -> None:
        pass

    def on_trade(self, trade: TradeView) -> None:
        pass

    def on_fill(self, fill: Fill) -> None:
        pass

    def on_end(self) -> None:
        pass

    # --- actions (delegate to the bound context) --------------------------------------

    def buy(self, symbol: Optional[str] = None, quantity: Number = 1) -> OrderReceipt:
        return self._require_ctx().buy(symbol, quantity)

    def sell(self, symbol: Optional[str] = None, quantity: Number = 1) -> OrderReceipt:
        return self._require_ctx().sell(symbol, quantity)

    def place_limit_order(
        self, symbol: Optional[str], side: Side, quantity: Number, price: Number
    ) -> OrderReceipt:
        return self._require_ctx().place_limit_order(symbol, side, quantity, price)

    def cancel_order(self, order_id: str) -> None:
        return self._require_ctx().cancel_order(order_id)

    # --- read shortcuts ----------------------------------------------------------------

    @property
    def market(self) -> MarketView:
        if self._market is None:
            raise NotConnected("market is only available while the strategy is running")
        return self._market

    def position(self, symbol: Optional[str] = None) -> Position:
        return self.market.position(symbol)

    @property
    def cash(self) -> Decimal:
        return self.market.cash

    @property
    def pnl(self) -> Decimal:
        return self.market.pnl

    # --- runner plumbing (not for students) -------------------------------------------

    def _bind(self, context: TradingContext, market: MarketView) -> None:
        self._ctx = context
        self._market = market

    def _require_ctx(self) -> TradingContext:
        if self._ctx is None:
            raise NotConnected(
                "trading actions are only available while the strategy is running "
                "(inside on_tick/on_orderbook, not in __init__)"
            )
        return self._ctx
