"""The read-only market interface passed to ``on_tick`` (and available as ``self.market``).

Exposes only public market data and your own account state — never hidden model parameters,
other teams' data, or engine internals. Single-asset competitions can omit the ``symbol``
argument everywhere; it defaults to the primary symbol.
"""
from __future__ import annotations

from decimal import Decimal
from typing import List, Optional

from .errors import UnknownSymbol
from .state import AccountState, MarketSnapshot
from .types import OrderBookView, Position, TradeView

__all__ = ["MarketView"]

_ZERO = Decimal(0)


class MarketView:
    def __init__(
        self,
        snapshot: MarketSnapshot,
        account: AccountState,
        symbols: List[str],
        primary_symbol: str,
    ) -> None:
        self._snap = snapshot
        self._account = account
        self._symbols = list(symbols)
        self._primary = primary_symbol

    # --- symbols / time ----------------------------------------------------------------

    @property
    def symbols(self) -> List[str]:
        return list(self._symbols)

    @property
    def step(self) -> int:
        return self._snap.step

    @property
    def timestamp(self) -> int:
        return self._snap.timestamp

    def _resolve(self, symbol: Optional[str]) -> str:
        sym = symbol or self._primary
        if sym not in self._symbols:
            raise UnknownSymbol(f"unknown symbol {sym!r}")
        return sym

    # --- public market data ------------------------------------------------------------

    def order_book(self, symbol: Optional[str] = None) -> OrderBookView:
        sym = self._resolve(symbol)
        return self._snap.books.get(sym, OrderBookView(sym))

    def bid(self, symbol: Optional[str] = None) -> Optional[Decimal]:
        return self.order_book(symbol).best_bid

    def ask(self, symbol: Optional[str] = None) -> Optional[Decimal]:
        return self.order_book(symbol).best_ask

    def mid(self, symbol: Optional[str] = None) -> Optional[Decimal]:
        return self.order_book(symbol).mid

    def spread(self, symbol: Optional[str] = None) -> Optional[Decimal]:
        return self.order_book(symbol).spread

    def price(self, symbol: Optional[str] = None) -> Optional[Decimal]:
        """Last traded price if available, else the current mid."""
        sym = self._resolve(symbol)
        last = self._snap.last_price.get(sym)
        return last if last is not None else self.mid(sym)

    def volume(self, symbol: Optional[str] = None) -> Decimal:
        return self._snap.volume.get(self._resolve(symbol), _ZERO)

    def recent_trades(self, symbol: Optional[str] = None, n: int = 20) -> List[TradeView]:
        trades = self._snap.recent_trades.get(self._resolve(symbol), ())
        return list(trades[-n:])

    # --- your own account (read-only) --------------------------------------------------

    def position(self, symbol: Optional[str] = None) -> Position:
        return self._account.position(self._resolve(symbol))

    @property
    def cash(self) -> Decimal:
        return self._account.cash

    @property
    def equity(self) -> Decimal:
        return self._account.equity

    @property
    def pnl(self) -> Decimal:
        """Total profit and loss (equity minus your starting cash)."""
        return self._account.total_pnl

    @property
    def realized_pnl(self) -> Decimal:
        return self._account.realized_pnl

    @property
    def unrealized_pnl(self) -> Decimal:
        return self._account.unrealized_pnl
