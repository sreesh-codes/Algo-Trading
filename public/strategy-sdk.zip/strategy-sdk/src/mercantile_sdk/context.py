"""The controlled action surface: validated order placement/cancellation.

A :class:`TradingContext` is the only thing that can change the market on the student's
behalf. Every action is validated (symbol, quantity, price, position limit, cash) before it
reaches the :class:`Broker`. The context holds *references* to the account/market state the
runner updates each step, and tracks the student's own open orders so position-limit checks
account for resting exposure.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Dict, Optional, Tuple

from .broker import Broker
from .errors import UnknownOrder
from .state import AccountState, MarketSnapshot
from .types import AssetSpec, Number, OrderReceipt, OrderType, Side, coerce_decimal
from .validation import (
    check_cash,
    check_position_limit,
    require_symbol,
    validate_price,
    validate_quantity,
)

__all__ = ["TradingContext"]

_ZERO = Decimal(0)


class TradingContext:
    def __init__(
        self,
        broker: Broker,
        registry: Dict[str, AssetSpec],
        account: AccountState,
        market: MarketSnapshot,
        primary_symbol: str,
    ) -> None:
        self._broker = broker
        self._registry = registry
        self._account = account
        self._market = market
        self._primary = primary_symbol
        # order_id -> (symbol, side, remaining_qty) for resting limit orders we placed.
        self._open: Dict[str, Tuple[str, Side, Decimal]] = {}

    # --- actions -----------------------------------------------------------------------

    def buy(self, symbol: Optional[str] = None, quantity: Number = 1) -> OrderReceipt:
        """Market buy ``quantity`` of ``symbol`` (defaults to the primary symbol)."""
        return self._market_order(symbol, Side.BUY, quantity)

    def sell(self, symbol: Optional[str] = None, quantity: Number = 1) -> OrderReceipt:
        """Market sell ``quantity`` of ``symbol``."""
        return self._market_order(symbol, Side.SELL, quantity)

    def place_limit_order(
        self, symbol: Optional[str], side: Side, quantity: Number, price: Number
    ) -> OrderReceipt:
        sym = symbol or self._primary
        spec = require_symbol(self._registry, sym)
        side = Side(side)
        qty = validate_quantity(spec, quantity)
        px = validate_price(spec, price)
        self._risk_checks(spec, side, qty, reference_price=px)
        oid = self._broker.submit(sym, side, OrderType.LIMIT, qty, px)
        self._open[oid] = (sym, side, qty)
        return OrderReceipt(oid, sym, side, OrderType.LIMIT, qty, px, _ZERO, "OPEN")

    def buy_limit(self, symbol: Optional[str], quantity: Number, price: Number) -> OrderReceipt:
        return self.place_limit_order(symbol, Side.BUY, quantity, price)

    def sell_limit(self, symbol: Optional[str], quantity: Number, price: Number) -> OrderReceipt:
        return self.place_limit_order(symbol, Side.SELL, quantity, price)

    def cancel_order(self, order_id: str) -> None:
        if order_id not in self._open:
            raise UnknownOrder(
                f"cannot cancel {order_id!r}: not one of your resting orders"
            )
        self._broker.cancel(order_id)
        self._open.pop(order_id, None)

    # --- internals ---------------------------------------------------------------------

    def _market_order(self, symbol: Optional[str], side: Side, quantity: Number) -> OrderReceipt:
        sym = symbol or self._primary
        spec = require_symbol(self._registry, sym)
        qty = validate_quantity(spec, quantity)
        # Reference price for cash check: best ask for buys, best bid for sells.
        book = self._market.books.get(sym)
        ref = None
        if book is not None:
            ref = book.best_ask if side is Side.BUY else book.best_bid
        self._risk_checks(spec, side, qty, reference_price=ref)
        oid = self._broker.submit(sym, side, OrderType.MARKET, qty, None)
        return OrderReceipt(oid, sym, side, OrderType.MARKET, qty, None, _ZERO, "SUBMITTED")

    def _pending(self, symbol: str) -> Tuple[Decimal, Decimal]:
        pending_buy = _ZERO
        pending_sell = _ZERO
        for sym, side, rem in self._open.values():
            if sym != symbol:
                continue
            if side is Side.BUY:
                pending_buy += rem
            else:
                pending_sell += rem
        return pending_buy, pending_sell

    def _risk_checks(
        self, spec: AssetSpec, side: Side, qty: Decimal, reference_price: Optional[Decimal]
    ) -> None:
        current = self._account.position(spec.symbol).quantity
        pending_buy, pending_sell = self._pending(spec.symbol)
        check_position_limit(spec, current, side, qty, pending_buy, pending_sell)
        if side is Side.BUY and reference_price is not None:
            estimated = qty * reference_price
            check_cash(self._account.cash, estimated)

    # --- runner hooks (not for students) ----------------------------------------------

    def _notify_fill(self, order_id: str, filled: Decimal) -> None:
        info = self._open.get(order_id)
        if info is None:
            return
        sym, side, rem = info
        rem = rem - filled
        if rem <= _ZERO:
            self._open.pop(order_id, None)
        else:
            self._open[order_id] = (sym, side, rem)

    def _notify_cancel(self, order_id: str) -> None:
        self._open.pop(order_id, None)

    @property
    def open_order_ids(self):
        return list(self._open)
