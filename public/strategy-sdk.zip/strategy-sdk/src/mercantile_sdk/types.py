"""Read-only data types the SDK hands to student strategies.

Everything here is immutable (frozen dataclasses / tuples) so a strategy can *read* market
and account state but cannot mutate the engine's view of the world. Monetary values are
Decimals internally; :func:`coerce_decimal` accepts the ints/floats/strings students
naturally write and converts them safely (floats via ``str`` to avoid binary noise).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import List, Optional, Tuple, Union

__all__ = [
    "Side",
    "OrderType",
    "Liquidity",
    "Number",
    "coerce_decimal",
    "AssetSpec",
    "Level",
    "OrderBookView",
    "TradeView",
    "Fill",
    "Position",
    "OrderReceipt",
]

Number = Union[Decimal, int, float, str]


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"

    def opposite(self) -> "Side":
        return Side.SELL if self is Side.BUY else Side.BUY


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"


class Liquidity(str, Enum):
    MAKER = "MAKER"
    TAKER = "TAKER"


def coerce_decimal(value: Number, *, field_name: str = "value") -> Decimal:
    """Coerce a student-supplied number to Decimal. Floats are allowed (via str)."""
    if isinstance(value, bool):
        raise TypeError(f"{field_name} must be a number, not a bool")
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        return Decimal(str(value))  # str() avoids 0.1+0.2 style noise
    if isinstance(value, str):
        try:
            return Decimal(value)
        except InvalidOperation as exc:
            raise ValueError(f"{field_name} {value!r} is not a valid number") from exc
    raise TypeError(f"{field_name} must be a number, got {type(value).__name__}")


@dataclass(frozen=True)
class AssetSpec:
    """Public trading rules for a tradable symbol (no hidden parameters)."""

    symbol: str
    tick_size: Decimal
    lot_size: Decimal
    price_precision: int
    position_limit: Decimal


@dataclass(frozen=True)
class Level:
    """One aggregated order-book price level."""

    price: Decimal
    size: Decimal


@dataclass(frozen=True)
class OrderBookView:
    """A read-only snapshot of one symbol's book (best first)."""

    symbol: str
    bids: Tuple[Level, ...] = field(default_factory=tuple)
    asks: Tuple[Level, ...] = field(default_factory=tuple)

    @property
    def best_bid(self) -> Optional[Decimal]:
        return self.bids[0].price if self.bids else None

    @property
    def best_ask(self) -> Optional[Decimal]:
        return self.asks[0].price if self.asks else None

    @property
    def mid(self) -> Optional[Decimal]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_bid + self.best_ask) / 2

    @property
    def spread(self) -> Optional[Decimal]:
        if self.best_bid is None or self.best_ask is None:
            return None
        return self.best_ask - self.best_bid


@dataclass(frozen=True)
class TradeView:
    """A public trade print from the tape (no counterparty identities)."""

    symbol: str
    price: Decimal
    quantity: Decimal
    taker_side: Side
    timestamp: int


@dataclass(frozen=True)
class Fill:
    """A fill of *your own* order, delivered to ``on_fill``."""

    order_id: str
    symbol: str
    side: Side
    quantity: Decimal
    price: Decimal
    fee: Decimal
    liquidity: Liquidity
    timestamp: int


@dataclass(frozen=True)
class Position:
    """Your holding in one symbol."""

    symbol: str
    quantity: Decimal
    average_price: Decimal
    realized_pnl: Decimal
    unrealized_pnl: Decimal


@dataclass(frozen=True)
class OrderReceipt:
    """Returned by buy/sell/place_limit_order: the order id and immediate outcome."""

    order_id: str
    symbol: str
    side: Side
    order_type: OrderType
    quantity: Decimal
    price: Optional[Decimal]
    filled_quantity: Decimal
    status: str
